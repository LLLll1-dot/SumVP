package GraphSummarization

object Const {
  final val DATASETS_PATH = "./datasets/"
//  final val TwentyK_PATY = DATASETS_PATH + "20k.txt"
//    final val ENRON_PATH = DATASETS_PATH + "Email-Enron.txt"
  final val ENRON_PATH = DATASETS_PATH + "20.txt"
//  final val rdfDataset_Path = DATASETS_PATH + "yagoFacts.tsv"
  final val rdfDataset_Path = DATASETS_PATH + "sparql_university_4_processed.txt"

  final val GOWALLA_PATH = DATASETS_PATH + "Gowalla_edges.txt"
  final val SKITTER_PATH = DATASETS_PATH + "as-skitter.txt"

  final val GRAPH_SUMMARIZATION_PATH = "./results/"
  //  final val TwentyK_SUMMARIZATION_PATY = GRAPH_SUMMARIZATION_PATH + "20k/"
//    final val ENRON_GRAPH_SUMMARIZATION_PATH = GRAPH_SUMMARIZATION_PATH + "Enron/"
  final val ENRON_GRAPH_SUMMARIZATION_PATH = GRAPH_SUMMARIZATION_PATH + "summ/"
  final val rdf_Graph_Summarization_Path = GRAPH_SUMMARIZATION_PATH + "yagoFacts/"

  final val GOWALLA_GRAPH_SUMMARIZATION_PATH = GRAPH_SUMMARIZATION_PATH + "Gowalla/"
  final val SKITTER_GRAPH_SUMMARIZATION_PATH = GRAPH_SUMMARIZATION_PATH + "as-skitter/"

}
